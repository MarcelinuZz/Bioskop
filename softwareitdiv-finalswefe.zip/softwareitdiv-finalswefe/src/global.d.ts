interface Window {
    snap: any;
  }