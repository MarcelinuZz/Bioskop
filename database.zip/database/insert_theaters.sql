insert into dbo.theaters (theater_id, theater_name, location, total_seats)
values  (1, N'Cine-Jaksel', N'Blok M, Jakarta Selatan', 60),
        (2, N'Cine-Alsut', N'Alam Sutera, Tangerang Selatan', 60),
        (3, N'Cine-Semarang', N'Semarang, Jawa Tengah', 60),
        (4, N'Cine-BSD', N'BSD City, Tangerang Selatan', 60);